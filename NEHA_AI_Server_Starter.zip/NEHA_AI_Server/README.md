# NEHA AI Server (Starter)

This is a small FastAPI backend for the NEHA AI website.

## Run locally
1. Install Python 3.10 or newer.
2. In this folder run: `pip install -r requirements.txt`
3. Run: `uvicorn main:app --host 0.0.0.0 --port 8000`
4. Open `http://127.0.0.1:8000` or `http://127.0.0.1:8000/docs`.

## Deploy
Push these files to a GitHub repository, then create a Render **Web Service**.
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

This starter does not yet connect to an AI model or store chat history. Do not put API keys in source code; add them later as private environment variables.
