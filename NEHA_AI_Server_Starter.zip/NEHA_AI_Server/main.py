from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="NEHA AI Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For a public launch, restrict this to your website domain.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str

@app.get("/")
def home():
    return {"app": "NEHA AI", "status": "online", "message": "NEHA AI server is running."}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat")
def chat(data: ChatRequest):
    user_message = data.message.strip()
    if not user_message:
        return {"reply": "তোমার প্রশ্নটি লিখে পাঠাও।"}
    # Starter response only. A real AI model will be connected in a later step.
    return {
        "reply": f"তুমি বলেছ: {user_message}\n\nআমি NEHA AI-এর প্রাথমিক সার্ভার। পরের ধাপে AI model যুক্ত করা হবে।"
    }
